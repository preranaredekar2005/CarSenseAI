"""
app.py - CarSense AI dashboard (Streamlit).
Run:  streamlit run app.py
"""
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

from agent import (build_assets, run_agent, parse_query, default_profile, compute_costs,
                   priority_scores, PRIORITIES, CRIT_LABELS)
from data import BODY_TYPES, FUEL_TYPES, CARS_DF
from evaluate import run_evaluation

st.set_page_config(page_title="CarSense AI", page_icon="🚗", layout="wide")


@st.cache_resource(show_spinner="Training the resale model and building the peer model...")
def get_assets():
    return build_assets()


@st.cache_data(show_spinner="Running the evaluation on 8 personas...")
def get_evaluation():
    return run_evaluation(get_assets())


assets = get_assets()

# ----------------------------------------------------------------------------
# Session state
# ----------------------------------------------------------------------------
defaults = default_profile()
for key, val in {"budget": 12.0, "seats": 5, "km": 12000, "usage": "Mixed", "fuels": list(FUEL_TYPES), "bodies": [],
                 "min_ncap": 0, "home": True, "years": 5}.items():
    st.session_state.setdefault(key, val)
for p in PRIORITIES:
    st.session_state.setdefault("pri_" + p, 5)
st.session_state.setdefault("liked", [])
st.session_state.setdefault("disliked", [])


def apply_query():
    prof = parse_query(st.session_state["nlq"])
    st.session_state.update({"budget": prof["budget_lakh"], "seats": prof["seats"], "km": prof["km_per_year"],
                             "usage": prof["usage"], "fuels": prof["fuels"], "bodies": prof["bodies"],
                             "home": prof["home_charging"]})
    for p in PRIORITIES:
        st.session_state["pri_" + p] = int(prof["priorities"][p])
    st.session_state["liked"], st.session_state["disliked"] = [], []


def like(i):
    if i not in st.session_state["liked"]:
        st.session_state["liked"].append(i)
    if i in st.session_state["disliked"]:
        st.session_state["disliked"].remove(i)


def dislike(i):
    if i not in st.session_state["disliked"]:
        st.session_state["disliked"].append(i)
    if i in st.session_state["liked"]:
        st.session_state["liked"].remove(i)


def reset_feedback():
    st.session_state["liked"], st.session_state["disliked"] = [], []


# ----------------------------------------------------------------------------
# Sidebar: buyer profile
# ----------------------------------------------------------------------------
with st.sidebar:
    st.title("🚗 CarSense AI")
    st.caption("Autonomous car-buying decision agent")
    st.text_area("Describe what you need", key="nlq", height=90,
                 placeholder="family of 5, budget 12 lakh, 15000 km per year, mostly city, want a safe SUV with good resale")
    st.button("Understand my request", on_click=apply_query, width="stretch")
    st.divider()
    st.number_input("On-road budget (Rs lakh)", 3.0, 60.0, step=0.5, key="budget")
    st.selectbox("Seats needed (minimum)", [4, 5, 7], key="seats")
    st.slider("Distance driven per year (km)", 3000, 40000, step=1000, key="km")
    st.selectbox("Usage", ["City", "Mixed", "Highway"], key="usage")
    st.slider("Ownership period (years)", 3, 8, key="years")
    st.multiselect("Allowed fuel types", FUEL_TYPES, key="fuels")
    st.multiselect("Body types (empty = any)", BODY_TYPES, key="bodies")
    st.selectbox("Minimum safety stars", [0, 3, 4, 5], key="min_ncap")
    st.checkbox("I can charge an EV at home", key="home")
    st.markdown("**What matters to you (1-10)**")
    for p in PRIORITIES:
        st.slider(p, 1, 10, key="pri_" + p)
    st.divider()
    st.markdown("**Hybrid weights**")
    wt = st.slider("TOPSIS (multi-criteria)", 0.0, 1.0, 0.6, 0.05)
    wc = st.slider("Content similarity", 0.0, 1.0, 0.2, 0.05)
    wp = st.slider("Peer (SVD collaborative)", 0.0, 1.0, 0.2, 0.05)

if not st.session_state["fuels"]:
    st.session_state["fuels"] = list(FUEL_TYPES)

profile = {"budget_lakh": st.session_state["budget"], "seats": st.session_state["seats"],
           "km_per_year": st.session_state["km"], "usage": st.session_state["usage"],
           "years": st.session_state["years"], "fuels": st.session_state["fuels"],
           "bodies": st.session_state["bodies"], "min_ncap": st.session_state["min_ncap"],
           "home_charging": st.session_state["home"],
           "priorities": {p: float(st.session_state["pri_" + p]) for p in PRIORITIES}}

mw = (wt, wc, wp) if (wt + wc + wp) > 0 else (0.6, 0.2, 0.2)
result = run_agent(profile, assets, liked=st.session_state["liked"], disliked=st.session_state["disliked"],
                   method_weights=mw)
ranked = result["ranked"]

# ----------------------------------------------------------------------------
# Header + KPIs
# ----------------------------------------------------------------------------
st.title("CarSense AI: your car-buying agent")
if len(ranked) < 2:
    st.error("No feasible cars were found, even after relaxing constraints. Try a higher budget.")
    st.stop()
if result["relaxed"]:
    st.warning("The agent re-planned because too few cars matched: " + "; ".join(result["relaxed"]) + ".")

top = ranked.iloc[0]
k1, k2, k3, k4 = st.columns(4)
k1.metric("Cars that fit", result["n_candidates"], f"of {len(CARS_DF)} in catalogue", delta_color="off")
k2.metric("Top recommendation", top["name"], f"{top['score']*100:.0f}/100 relative score", delta_color="off")
k3.metric(f"{profile['years']}-yr total cost of ownership", f"Rs {top['tco']/1e5:.1f} L",
          f"Rs {top['tco_per_km']:.1f} per km", delta_color="off")
k4.metric("Decision stability", f"{top['stability']*100:.0f}%", "stays top-3 under +-20% weight change", delta_color="off")

tabs = st.tabs(["🏆 Recommendations", "🧠 Agent reasoning", "💰 Cost breakdown", "🔮 What-if and EV break-even",
                "⚖️ Compare", "📊 Evaluation"])

# ----------------------------------------------------------------------------
# Tab 1: recommendations
# ----------------------------------------------------------------------------
with tabs[0]:
    st.subheader("Top picks for you")
    st.caption("Give a 👍 or 👎 and the agent learns your real priorities and re-ranks instantly.")
    for i, row in ranked.head(5).iterrows():
        with st.container(border=True):
            c1, c2, c3 = st.columns([4, 3, 1.2])
            tag = " 👍" if i in st.session_state["liked"] else (" 👎" if i in st.session_state["disliked"] else "")
            c1.markdown(f"### #{int(row['rank'])}  {row['name']}{tag}")
            c1.write(row["why"])
            c2.markdown(f"**{row['fuel']}** · {row['body']} · {int(row['seats'])} seats · {int(row['ncap'])}★  \n"
                        f"On-road **Rs {row['onroad_lakh']:.1f} L** · {profile['years']}-yr TCO **Rs {row['tco']/1e5:.1f} L**  \n"
                        f"Running cost **Rs {row['cost_km']:.1f}/km** · Resale **{row['resale_pct']:.0f}%**")
            c3.metric("Relative score", f"{row['score']*100:.0f}/100")
            b1, b2 = c3.columns(2)
            b1.button("👍", key=f"l{i}", on_click=like, args=(i,))
            b2.button("👎", key=f"d{i}", on_click=dislike, args=(i,))
    if st.session_state["liked"] or st.session_state["disliked"]:
        st.button("Reset feedback", on_click=reset_feedback)
    st.subheader("Full shortlist")
    table = ranked[["rank", "name", "fuel", "body", "onroad_lakh", "tco", "cost_km", "ncap", "resale_pct",
                    "score", "stability"]].copy()
    table["tco"] = (table["tco"] / 1e5).round(2)
    table["score"] = (table["score"] * 100).round(0)
    table["stability"] = (table["stability"] * 100).round(0)
    table.columns = ["Rank", "Car", "Fuel", "Body", "On-road (L)", f"{profile['years']}-yr TCO (L)", "Rs/km", "Safety", "Resale %",
                     "Relative score", "Stability %"]
    st.dataframe(table.round(2), hide_index=True, width="stretch")

# ----------------------------------------------------------------------------
# Tab 2: agent reasoning
# ----------------------------------------------------------------------------
with tabs[1]:
    st.subheader("How the agent decided")
    st.markdown("The agent follows a **Perceive → Estimate → Filter/Re-plan → Score → Decide → Explain → Learn** loop. "
                "Every step is logged below for this exact request.")
    for step in result["trace"]:
        label, _, rest = step.partition(": ")
        st.markdown(f"**{label}**  \n{rest}")
    c1, c2 = st.columns(2)
    wdf = pd.DataFrame({"Criterion": CRIT_LABELS, "Weight": result["weights"]})
    c1.plotly_chart(px.bar(wdf, x="Weight", y="Criterion", orientation="h", title="Final TOPSIS criteria weights "
                           "(75% your priorities + 25% data-driven entropy weights)"), width="stretch")
    comp = ranked.head(10).copy()
    comp["TOPSIS"], comp["Content"], comp["Peer"] = mw[0] / sum(mw) * comp["topsis"], mw[1] / sum(mw) * comp["content"], mw[2] / sum(mw) * comp["peer"]
    fig = px.bar(comp, x="name", y=["TOPSIS", "Content", "Peer"], title="Where each top-10 score comes from",
                 labels={"value": "Weighted score", "name": ""})
    c2.plotly_chart(fig, width="stretch")
    st.info("Learned priorities: " + ", ".join(f"{k} {v:.1f}" for k, v in result["priorities"].items()))

# ----------------------------------------------------------------------------
# Tab 3: cost breakdown
# ----------------------------------------------------------------------------
with tabs[2]:
    st.subheader(f"Where your money goes over {profile['years']} years")
    t5 = ranked.head(5)
    cb = pd.DataFrame({"Car": t5["name"], "Depreciation (price - resale)": t5["depreciation"] / 1e5,
                       "Fuel / charging": t5["fuel_cost"] / 1e5, "Servicing": t5["maint_cost"] / 1e5,
                       "Insurance": t5["ins_cost"] / 1e5})
    fig = px.bar(cb.melt(id_vars="Car", var_name="Component", value_name="Rs lakh"), x="Car", y="Rs lakh",
                 color="Component", title="5-car total cost of ownership (Rs lakh)")
    st.plotly_chart(fig, width="stretch")
    st.caption("All figures are academic estimates, not dealer quotations. Resale is predicted from synthetic training data. "
               "Illustrative fuel assumptions: petrol Rs 104/L, diesel Rs 91/L, CNG Rs 90/kg; electricity Rs 8/kWh at home "
               "and Rs 18/kWh public. Real-world mileage is modelled at 85% of the claimed figure. Verify local prices, "
               "insurance, taxes, service schedules and variant specifications before making a purchase.")

# ----------------------------------------------------------------------------
# Tab 4: what-if and EV break-even
# ----------------------------------------------------------------------------
with tabs[3]:
    st.subheader("What if you drive more or less?")
    kms = list(range(3000, 40001, 3000))
    curves = {}
    for km in kms:
        c = compute_costs({**profile, "km_per_year": km}, assets["model"])
        for i in ranked.head(5).index:
            curves.setdefault(c.loc[i, "name"], []).append(c.loc[i, "tco"] / 1e5)
    wf = pd.DataFrame(curves, index=kms).reset_index().melt(id_vars="index", var_name="Car", value_name="TCO (Rs lakh)")
    st.plotly_chart(px.line(wf, x="index", y="TCO (Rs lakh)", color="Car", markers=True,
                            labels={"index": "Kilometres per year"}, title="Total cost of ownership vs annual distance"),
                    width="stretch")

    st.subheader("EV vs fuel car break-even")
    names = CARS_DF["name"].tolist()
    a, b = st.columns(2)
    ice = a.selectbox("Fuel car", [n for n in names if CARS_DF.set_index("name").loc[n, "fuel"] != "Electric"],
                      index=names.index("Tata Nexon") if "Tata Nexon" in names else 0)
    ev = b.selectbox("Electric car", [n for n in names if CARS_DF.set_index("name").loc[n, "fuel"] == "Electric"], index=2)
    grid = list(range(2000, 40001, 2000))
    ia, ib = CARS_DF.index[CARS_DF["name"] == ice][0], CARS_DF.index[CARS_DF["name"] == ev][0]
    ta, tb = [], []
    for km in grid:
        c = compute_costs({**profile, "km_per_year": km}, assets["model"])
        ta.append(c.loc[ia, "tco"] / 1e5)
        tb.append(c.loc[ib, "tco"] / 1e5)
    diff = np.array(tb) - np.array(ta)
    fig = go.Figure([go.Scatter(x=grid, y=ta, name=ice), go.Scatter(x=grid, y=tb, name=ev)])
    fig.update_layout(xaxis_title="Kilometres per year", yaxis_title="TCO (Rs lakh)", title="Break-even analysis")
    st.plotly_chart(fig, width="stretch")
    cross = np.where(np.sign(diff[:-1]) != np.sign(diff[1:]))[0]
    if len(cross):
        j = cross[0]
        be = grid[j] + (grid[j + 1] - grid[j]) * (0 - diff[j]) / (diff[j + 1] - diff[j])
        st.success(f"Break-even at about **{be:,.0f} km/year**. Above this the EV is the cheaper choice over {profile['years']} years.")
    elif diff[0] < 0:
        st.success(f"{ev} is cheaper than {ice} at every distance in this range.")
    else:
        st.warning(f"{ice} stays cheaper than {ev} up to 40,000 km/year under these assumptions.")

# ----------------------------------------------------------------------------
# Tab 5: compare
# ----------------------------------------------------------------------------
with tabs[4]:
    st.subheader("Side-by-side comparison")
    pick = st.multiselect("Choose 2-4 cars", ranked["name"].tolist(), default=ranked["name"].head(3).tolist(), max_selections=4)
    if len(pick) >= 2:
        sel = ranked[ranked["name"].isin(pick)]
        ps = priority_scores(ranked).loc[sel.index]
        fig = go.Figure()
        for i in sel.index:
            fig.add_trace(go.Scatterpolar(r=ps.loc[i].tolist() + [ps.loc[i].iloc[0]], theta=PRIORITIES + [PRIORITIES[0]],
                                          fill="toself", name=sel.loc[i, "name"]))
        fig.update_layout(polar=dict(radialaxis=dict(range=[0, 1])), title="Priority scores (1 = best in shortlist)")
        st.plotly_chart(fig, width="stretch")
        cmp = sel.set_index("name")[["fuel", "onroad_lakh", "tco", "cost_km", "bhp", "boot_l", "clearance", "ncap", "resale_pct"]].copy()
        cmp["tco"] = cmp["tco"] / 1e5
        cmp.columns = ["Fuel", "On-road (Rs L)", f"{profile['years']}-yr TCO (Rs L)", "Running cost (Rs/km)", "Power (bhp)", "Boot (L)",
                       "Clearance (mm)", "Safety (stars)", "Resale (%)"]
        cmp = cmp.T.astype(str)   # one text column per car (mixed text and numbers)
        st.dataframe(cmp, width="stretch")
    else:
        st.info("Pick at least two cars.")

# ----------------------------------------------------------------------------
# Tab 6: evaluation
# ----------------------------------------------------------------------------
with tabs[5]:
    ev = get_evaluation()
    st.subheader("Does the agent actually work? Evaluation on 8 buyer personas")
    st.markdown("Ground truth = expert-written **must-have rules** per persona (for example 5-star safety, boot of 350 L or more, "
                "within budget). The agent never sees these rules, only the persona's profile and sliders.")
    s = ev["summary"]
    c1, c2 = st.columns(2)
    for col, metric in zip([c1, c2], ["Precision@5", "NDCG@5"]):
        fig = px.bar(s.reset_index(), x=metric, y="method", orientation="h", range_x=[0, 1], title=metric + " (mean of 8 personas)")
        fig.update_yaxes(autorange="reversed")
        col.plotly_chart(fig, width="stretch")
    st.dataframe(s, width="stretch")
    st.markdown("**Resale model (tested on car models it never saw during training)**")
    m = ev["resale_metrics"]
    r1, r2, r3 = st.columns(3)
    r1.metric("MAE", f"{m['MAE (pct points)']:.2f} pct pts")
    r2.metric("RMSE", f"{m['RMSE (pct points)']:.2f} pct pts")
    r3.metric("R²", f"{m['R2']:.3f}")
    y, p = ev["test_pairs"]
    d1, d2 = st.columns(2)
    d1.plotly_chart(px.scatter(x=y, y=p, labels={"x": "Actual resale %", "y": "Predicted resale %"}, title="Predicted vs actual"),
                    width="stretch")
    imp = ev["importances"].head(8).reset_index()
    imp.columns = ["feature", "importance"]
    d2.plotly_chart(px.bar(imp, x="importance", y="feature", orientation="h", title="Random Forest feature importance"),
                    width="stretch")
    st.markdown("**Per-persona stability and feasibility**")
    st.dataframe(ev["stability"], hide_index=True, width="stretch")
    st.caption("Research limitations: the catalogue contains 61 illustrative car models with rounded academic values; "
               "resale targets and peer ratings are synthetic; maintenance and insurance are formula-based estimates; "
               "personas are expert-defined. These results demonstrate the method, not production-grade market accuracy. "
               "Real used-car transaction data and verified variant-level specifications are needed for deployment.")
